sudo tc qdisc del dev lo root;
echo "clear tc";