import sys
import socket


def receiver(r_port, file_name, window_size):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.bind(('127.0.0.1', r_port))
    cache = {}
    base = 0

    while True:
        pkt, addr = sock.recvfrom(1027)
        now_seq = int.from_bytes(pkt[:2], 'big')
        print("@@@rcv: " + str(now_seq) + " base: " + str(base))
        if base < now_seq < base + window_size:
            print("@@@cache: " + str(now_seq))
            cache[now_seq] = pkt[3:]
            sock.sendto(pkt[:2], addr)
        elif base - window_size <= now_seq <= base - 1:
            print("@@@discard: " + str(now_seq))
            sock.sendto(pkt[:2], addr)
        elif base == now_seq:
            cache[now_seq] = pkt[3:]
            for i in range(base, base + window_size):
                if i not in cache:
                    base = i

            if pkt[2] == 1:
                for i in range(5):
                    sock.sendto(pkt[:2], addr)
                break
            sock.sendto(pkt[:2], addr)

    sock.close()
    with open(file_name, 'wb') as f:
        for i in cache:
            f.write(cache[i])


if __name__ == '__main__':
    # print("receiver start")
    r_port = int(sys.argv[1])
    file_name = sys.argv[2]
    window_size = int(sys.argv[3])
    receiver(r_port, file_name, window_size)
    # print("receiver end")
